# 📱 WhatsApp Notification Clone (React Native)

This is a sample React Native project that demonstrates WhatsApp-style push notifications using Firebase Cloud Messaging.

## 🔧 Features
- Push notifications using Firebase
- Native Android notification service (Kotlin)
- Background and killed-state notification handling
- Deep linking to CallScreen

## 🚀 Getting Started
1. Clone repo
2. Setup Firebase project
3. Place `google-services.json` in `android/app/`
4. Run `npx react-native run-android`

## 🛠 Technologies
- React Native CLI
- Kotlin for Android
- Firebase Cloud Messaging
