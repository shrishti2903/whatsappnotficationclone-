import React, { useEffect } from 'react';
import messaging from '@react-native-firebase/messaging';
import { Alert } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import CallScreen from './src/screens/CallScreen';

const Stack = createStackNavigator();

const App = () => {
  useEffect(() => {
    messaging().onMessage(async remoteMessage => {
      Alert.alert(remoteMessage.notification?.title ?? '', remoteMessage.notification?.body ?? '');
    });

    messaging()
      .getToken()
      .then(token => console.log('FCM Token:', token));
  }, []);

  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="CallScreen" component={CallScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;
